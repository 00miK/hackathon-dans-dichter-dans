<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="DDD brengt spoken word tot leven met live events en performances.">
<title>Accueil — Dans! Dichter! Dans!</title>

<!-- CSS principal  -->
<link rel="stylesheet" href="/PROJET-SOCIETE/assets/css/main.css">

<!-- Icônes FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

  <header class="navbar" id="navbar">
  <div class="navbar__inner">

    <nav class="navbar__left">
      <ul class="navbar__links">
        <li><a href="/PROJET-SOCIETE/pages/about.php" class="navbar__link">About</a></li>
        <li><a href="/PROJET-SOCIETE/pages/events.php" class="navbar__link">Events</a></li>
      </ul>
    </nav>

    <a href="/PROJET-SOCIETE/index.php" class="navbar__logo">
      <img src="/PROJET-SOCIETE/assets/img/logo.png" alt="Dans! Dichter! Dans!">
    </a>

    <nav class="navbar__right">
      <ul class="navbar__links">
        <li><a href="/PROJET-SOCIETE/pages/archives.php" class="navbar__link">Archives</a></li>
        <li><a href="/PROJET-SOCIETE/contact.php" class="navbar__link">Contact</a></li>
      </ul>
    </nav>

    <button class="navbar__burger" id="burger-btn" aria-label="Ouvrir le menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>

  </div>

  <!-- Menu mobile combiné — toutes les pages -->
  <nav class="navbar__mobile-menu" id="mobile-menu" aria-hidden="true">
    <ul>
      <li><a href="/PROJET-SOCIETE/pages/about.php">About</a></li>
      <li><a href="/PROJET-SOCIETE/pages/events.php">Events</a></li>
      <li><a href="/PROJET-SOCIETE/pages/archives.php">Archives</a></li>
      <li><a href="/PROJET-SOCIETE/contact.php">Contact</a></li>
    </ul>
  </nav>

</header>
  <main>

    <!-- ==============================
         HERO — Vidéo YouTube
    ============================== -->
    <section class="hero">
      <div class="hero__video-wrapper">
        <iframe
          id="hero-video"
          src="https://www.youtube.com/embed/zvKhIGSS0Kw?autoplay=1&mute=1&loop=1&playlist=zvKhIGSS0Kw&controls=0&showinfo=0&rel=0&modestbranding=1&playsinline=1"
          title="Hero background video"
          allow="autoplay; encrypted-media"
          allowfullscreen>
        </iframe>
        <div class="hero__overlay"></div>
        <div class="hero__content">
          <h1 class="hero__title">Waar woorden het<br>podium vinden.</h1>
          <p class="hero__subtitle">DDD brengt spoken word tot leven<br>met live events en performances.</p>
          <a href="/PROJET-SOCIETE/pages/events.php" class="btn btn--hero">Bekijk het komende event</a>
        </div>
      </div>
    </section>


    <!-- ==============================
         À PROPOS
    ============================== -->
    <section class="section about" id="about">
      <div class="container about__content">
        <h2 class="about__title">Over Dans! Dichter! Dans!</h2>
        <p class="about__text">Dans! Dichter! Dans! is een platform waar spoken word centraal staat. We ondersteunen opkomende artiesten en geven hen een podium om hun verhalen te delen.</p>
        <p class="about__text">Door middel van live performances, interviews en media bouwen we aan een gemeenschap waar woorden kracht krijgen.</p>
        <a href="/PROJET-SOCIETE/pages/about.php" class="btn btn--pink">Meer over ons</a>
      </div>
    </section>


    <!-- ==============================
         KOMENDE EVENTS
    ============================== -->
    <section class="section events" id="events">
      <div class="container">
        <div class="events__header">
          <h2 class="events__title">Komende events</h2>
          <a href="/PROJET-SOCIETE/pages/events.php" class="btn btn--pink">Bekijk alle events</a>
        </div>
        <div class="events__grid">

          <article class="event-card fade-in">
            <div class="event-card__img">
              <img src="/PROJET-SOCIETE/assets/img/hp1.jpeg" alt="Dans! Dichter! Dans! 2026">
            </div>
            <div class="event-card__body">
              <h3 class="event-card__title">Dans! Dichter! Dans! 2026</h3>
              <p class="event-card__meta"><i class="fa-regular fa-calendar"></i> 12 maart 2026 - 20:00</p>
              <p class="event-card__meta"><i class="fa-solid fa-location-dot"></i> Heilig-Hartstraat 16, 9040 Sint-Amandsberg</p>
              <p class="event-card__desc">Een avond vol spoken word, performance en nieuwe stemmen. Ontdek krachtige verhalen en unieke performances van opkomende artiesten.</p>
            </div>
          </article>

          <article class="event-card fade-in">
            <div class="event-card__img">
              <img src="/PROJET-SOCIETE/assets/img/hp2.jpeg" alt="Dans! Dichter! Dans! 2026">
            </div>
            <div class="event-card__body">
              <h3 class="event-card__title">Open Mic Night</h3>
              <p class="event-card__meta"><i class="fa-regular fa-calendar"></i> 18 april 2026 — 19:30</p>
              <p class="event-card__meta"><i class="fa-solid fa-location-dot"></i> Triomflaan 8, 1160 Brussel</p>
              <p class="event-card__desc">Een avond vol spoken word, performance en nieuwe stemmen. Ontdek krachtige verhalen en unieke performances van opkomende artiesten.</p>
            </div>
          </article>

          <article class="event-card fade-in">
            <div class="event-card__img">
              <img src="/PROJET-SOCIETE/assets/img/hp3.jpeg" alt="Dans! Dichter! Dans! 2026">
            </div>
            <div class="event-card__body">
              <h3 class="event-card__title">Poetry & Performance Night</h3>
              <p class="event-card__meta"><i class="fa-regular fa-calendar"></i> 7 juni 2026 — 20:30</p>
              <p class="event-card__meta"><i class="fa-solid fa-location-dot"></i> Anspachlaan 110, 1000 Brussel</p>
              <p class="event-card__desc">Een avond vol spoken word, performance en nieuwe stemmen. Ontdek krachtige verhalen en unieke performances van opkomende artiesten..</p>
            </div>
          </article>

          <article class="event-card fade-in">
            <div class="event-card__img">
              <img src="/PROJET-SOCIETE/assets/img/hp4.jpeg" alt="Dans! Dichter! Dans! 2026">
            </div>
            <div class="event-card__body">
              <h3 class="event-card__title">Summer Spoken Word Session</h3>
              <p class="event-card__meta"><i class="fa-regular fa-calendar"></i> 22 augustus 2026 — 19:00</p>
              <p class="event-card__meta"><i class="fa-solid fa-location-dot"></i> Adolphe Lavalléestraat 39, 1080 Brussel</p>
              <p class="event-card__desc">Een avond vol spoken word, performance en nieuwe stemmen. Ontdek krachtige verhalen en unieke performances van opkomende artiesten.</p>
            </div>
          </article>

        </div>
      </div>
    </section>


    <!-- ==============================
         IMPACT IN CIJFERS
    ============================== -->
    <section class="section impact" id="impact">
      <div class="container">
        <h2 class="impact__title">
          Onze <em class="impact__accent">impact</em> in cijfers
        </h2>
        <div class="impact__grid">
          <div class="impact__stat">
            <span class="impact__number">10+</span>
            <span class="impact__label">Edities georganiseerd</span>
          </div>
          <div class="impact__divider"></div>
          <div class="impact__stat">
            <span class="impact__number">150+</span>
            <span class="impact__label">Artiesten op het podium</span>
          </div>
          <div class="impact__divider"></div>
          <div class="impact__stat">
            <span class="impact__number">1000+</span>
            <span class="impact__label">Bezoekers</span>
          </div>
          <div class="impact__divider"></div>
          <div class="impact__stat">
            <span class="impact__number">5</span>
            <span class="impact__label">Jaar actief</span>
          </div>
        </div>
      </div>
    </section>

  </main>

  <footer class="footer">
  <div class="container footer__inner">

    <!-- Logo + description -->
    <div class="footer__brand">
      <a href="/PROJET-SOCIETE/index.php">
        <img src="/PROJET-SOCIETE/assets/img/logo.png" alt="Dans! Dichter! Dans!" class="footer__logo">
      </a>
      <p class="footer__desc">Un espace où les artistes se rencontrent et où la performance devient mouvement.</p>
    </div>

    <!-- Colonne Media -->
    <nav class="footer__nav" aria-label="Media">
      <h3 class="footer__nav-title">Company</h3>
      <ul>
        <li><a href="/PROJET-SOCIETE/pages/interviews.php">About</a></li>
        <li><a href="/PROJET-SOCIETE/pages/podcast.php">Contact</a></li>

      </ul>
    </nav>

    <!-- Colonne Company -->
    <nav class="footer__nav" aria-label="Company">
      <h3 class="footer__nav-title">Events</h3>
      <ul>
        <li><a href="/PROJET-SOCIETE/pages/about.php">Interviews </a></li>
        <li><a href="/PROJET-SOCIETE/pages/events.php">Podcast</a></li>
        <li><a href="/PROJET-SOCIETE/pages/past-editions.php">Aftermovies</a></li>
        <li><a href="/PROJET-SOCIETE/pages/open-call.php">Teasers</a></li>
      </ul>
    </nav>

    <!-- Newsletter + réseaux sociaux -->
    <div class="footer__newsletter">
      <h3 class="footer__nav-title">Join a Newsletter</h3>
      <label for="newsletter-email">Your Email</label>
      <div class="footer__newsletter-form">
        <input type="email" id="newsletter-email" placeholder="Enter Your Email">
        <button type="button">Subscribe</button>
      </div>
      <div class="footer__social">
        <a href="http://www.instagram.com/dansdichterdans" target="_blank" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
        <a href="https://www.facebook.com/dansdichterdans" target="_blank" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="https://www.youtube.com/channel/UCeXigmFpXBc70l3487iY1jQ" target="_blank" aria-label="Youtube"><i class="fa-brands fa-youtube"></i></a>
      </div>
    </div>

  </div>

  <!-- Barre du bas -->
  <div class="footer__bottom">
    <p>Copyright Team 5</p>
    <div class="footer__bottom-info">
      <span><i class="fa-solid fa-location-dot"></i> Heilig-Hartstraat 16, 9040 Sint-Amandsberg</span>
      <span><i class="fa-solid fa-envelope"></i> info@dansdichterdans.be</span>
      <span><i class="fa-solid fa-phone"></i> +32 488 86 82 11</span>
    </div>
  </div>
</footer>

<script src="/PROJET-SOCIETE/assets/js/main.js"></script>
</body>
</html>