<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Découvrez toutes les éditions passées de Dans! Dichter! Dans!">
<title>Archives — Dans! Dichter! Dans!</title>

<!-- CSS principal  -->
<link rel="stylesheet" href="/PROJET-SOCIETE/assets/css/main.css">

<!-- Icônes FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

  <header class="navbar" id="navbar">
  <div class="navbar__inner">

    <nav class="navbar__left">
      <ul class="navbar__links">
        <li><a href="/PROJET-SOCIETE/pages/about.php" class="navbar__link">About</a></li>
        <li><a href="/PROJET-SOCIETE/pages/events.php" class="navbar__link">Events</a></li>
      </ul>
    </nav>

    <a href="/PROJET-SOCIETE/index.php" class="navbar__logo">
      <img src="/PROJET-SOCIETE/assets/img/logo.png" alt="Dans! Dichter! Dans!">
    </a>

    <nav class="navbar__right">
      <ul class="navbar__links">
        <li><a href="/PROJET-SOCIETE/pages/archives.php" class="navbar__link">Archives</a></li>
        <li><a href="/PROJET-SOCIETE/contact.php" class="navbar__link">Contact</a></li>
      </ul>
    </nav>

    <button class="navbar__burger" id="burger-btn" aria-label="Ouvrir le menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>

  </div>

  <!-- Menu mobile combiné — toutes les pages -->
  <nav class="navbar__mobile-menu" id="mobile-menu" aria-hidden="true">
    <ul>
      <li><a href="/PROJET-SOCIETE/pages/about.php">About</a></li>
      <li><a href="/PROJET-SOCIETE/pages/events.php">Events</a></li>
      <li><a href="/PROJET-SOCIETE/pages/archives.php">Archives</a></li>
      <li><a href="/PROJET-SOCIETE/contact.php">Contact</a></li>
    </ul>
  </nav>

</header>
  <!-- Décorations roses flottantes -->
  <div class="archives-deco archives-deco--tr" aria-hidden="true">d</div>
  <div class="archives-deco archives-deco--mr" aria-hidden="true">q</div>
  <div class="archives-deco archives-deco--br" aria-hidden="true">d</div>
  <div class="archives-deco archives-deco--ml" aria-hidden="true">p</div>

  <main class="archives-page">
    <div class="container">

      <h1 class="archives-page__title">Archives</h1>

      <div class="timeline">

        <!-- ========================
             2015
        ======================== -->
        <div class="timeline__year-block">
          <div class="timeline__year-marker">2015</div>
          <div class="timeline__ticks">
            <span></span><span></span><span></span>
            <span></span><span></span><span></span>
            <span></span><span></span>
          </div>
          <div class="timeline__events-grid">

            <article class="event-archive-card reveal" style="--reveal-delay: 0s">
              <div class="event-archive-card__img">
                <img src="/PROJET-SOCIETE/assets/img/ar1.jpeg" alt="Dans! Dichter! Dans! #2">
              </div>
              <div class="event-archive-card__body">
                <h3 class="event-archive-card__title">Dans! Dichter! Dans! #2</h3>
                <p class="event-archive-card__date"><i class="fa-regular fa-calendar"></i> 23/06/2015</p>
                <p class="event-archive-card__desc">Literatuur en feest — dansend tegen de duisternis, met absint.</p>
                <a href="#" class="event-archive-card__btn">Bekijk de video</a>
              </div>
            </article>

            <article class="event-archive-card reveal" style="--reveal-delay: 0.12s">
              <div class="event-archive-card__img">
                <img src="/PROJET-SOCIETE/assets/img/ar2.jpeg" alt="Dans! Dichter! Dans! #4">
              </div>
              <div class="event-archive-card__body">
                <h3 class="event-archive-card__title">Dans! Dichter! Dans! #4</h3>
                <p class="event-archive-card__date"><i class="fa-regular fa-calendar"></i> 10/12/2015</p>
                <p class="event-archive-card__desc">Hannah Pinson, Stefanie Huysmans en Maarten Luyten startten met acht jazzmuzikanten Dans! Dichter! Dans!</p>
                <a href="#" class="event-archive-card__btn">Bekijk de video</a>
              </div>
            </article>

          </div>
        </div>

        <!-- ========================
             2016
        ======================== -->
        <div class="timeline__year-block">
          <div class="timeline__year-marker">2016</div>
          <div class="timeline__ticks">
            <span></span><span></span><span></span>
            <span></span><span></span><span></span>
            <span></span><span></span>
          </div>
          <div class="timeline__events-grid">

            <article class="event-archive-card reveal" style="--reveal-delay: 0s">
              <div class="event-archive-card__img">
                <img src="/PROJET-SOCIETE/assets/img/ar3.jpeg" alt="Dans! Dichter! Dans! #5">
              </div>
              <div class="event-archive-card__body">
                <h3 class="event-archive-card__title">Dans! Dichter! Dans! #5</h3>
                <p class="event-archive-card__date"><i class="fa-regular fa-calendar"></i> 05/02/2016</p>
                <p class="event-archive-card__desc">Uitgenodigd door Het Bos op ARTRAVE — sterk, maar minder intiem.</p>
                <a href="#" class="event-archive-card__btn">Bekijk de video</a>
              </div>
            </article>

            <article class="event-archive-card reveal" style="--reveal-delay: 0.12s">
              <div class="event-archive-card__img">
                <img src="/PROJET-SOCIETE/assets/img/ar4.jpeg" alt="Dans! Dichter! Dans! #6">
              </div>
              <div class="event-archive-card__body">
                <h3 class="event-archive-card__title">Dans! Dichter! Dans! #6</h3>
                <p class="event-archive-card__date"><i class="fa-regular fa-calendar"></i> 04/05/2016</p>
                <p class="event-archive-card__desc">We verwelkomden 150 mensen; dj's, bands en livestreams met interviews door STUDIO 03.</p>
                <a href="#" class="event-archive-card__btn">Bekijk de video</a>
              </div>
            </article>

          </div>
        </div>

        <!-- ========================
             2017
        ======================== -->
        <div class="timeline__year-block">
          <div class="timeline__year-marker">2017</div>
          <div class="timeline__ticks">
            <span></span><span></span><span></span>
            <span></span><span></span><span></span>
            <span></span><span></span>
          </div>
          <div class="timeline__events-grid">

            <article class="event-archive-card reveal" style="--reveal-delay: 0s">
              <div class="event-archive-card__img">
                <img src="/PROJET-SOCIETE/assets/img/ar5.jpeg" alt="Dans! Dichter! Dans! #12">
              </div>
              <div class="event-archive-card__body">
                <h3 class="event-archive-card__title">Dans! Dichter! Dans! #12</h3>
                <p class="event-archive-card__date"><i class="fa-regular fa-calendar"></i> 28/09/2017</p>
                <p class="event-archive-card__desc">Met schrijvers, het Dans! Dichter! Dans!-collectief, dj's en Roda Lits naar Ampere — visuals door MONTAGE.</p>
                <a href="#" class="event-archive-card__btn">Bekijk de video</a>
              </div>
            </article>

            <article class="event-archive-card reveal" style="--reveal-delay: 0.12s">
              <div class="event-archive-card__img">
                <img src="/PROJET-SOCIETE/assets/img/ar6.jpeg" alt="Dans! Dichter! Dans! #9">
              </div>
              <div class="event-archive-card__body">
                <h3 class="event-archive-card__title">Dans! Dichter! Dans! #9</h3>
                <p class="event-archive-card__date"><i class="fa-regular fa-calendar"></i> 15/03/2017</p>
                <p class="event-archive-card__desc">We doopten de refter van Conservatorium Antwerpen om tot 'Club Cons'.</p>
                <a href="#" class="event-archive-card__btn">Bekijk de video</a>
              </div>
            </article>

          </div>
        </div>

        <!-- ========================
             2018
        ======================== -->
        <div class="timeline__year-block">
          <div class="timeline__year-marker">2018</div>
          <div class="timeline__ticks">
            <span></span><span></span><span></span>
            <span></span><span></span><span></span>
            <span></span><span></span>
          </div>
          <div class="timeline__events-grid">

            <article class="event-archive-card reveal" style="--reveal-delay: 0s">
              <div class="event-archive-card__img">
                <img src="/PROJET-SOCIETE/assets/img/ar7.jpeg" alt="Dans! Dichter! Dans! #14">
              </div>
              <div class="event-archive-card__body">
                <h3 class="event-archive-card__title">Dans! Dichter! Dans! #14</h3>
                <p class="event-archive-card__date"><i class="fa-regular fa-calendar"></i> 20/07/2018</p>
                <p class="event-archive-card__desc">Met dichters van Auw La stonden we tijdens de Gentse Feesten in een volle spiegeltent — onze eerste editie in Gent.</p>
                <a href="#" class="event-archive-card__btn">Bekijk de video</a>
              </div>
            </article>

            <article class="event-archive-card reveal" style="--reveal-delay: 0.12s">
              <div class="event-archive-card__img">
                <img src="/PROJET-SOCIETE/assets/img/ar8.jpeg" alt="Dans! Dichter! Dans! #15">
              </div>
              <div class="event-archive-card__body">
                <h3 class="event-archive-card__title">Dans! Dichter! Dans! #15</h3>
                <p class="event-archive-card__date"><i class="fa-regular fa-calendar"></i> 16/10/2018</p>
                <p class="event-archive-card__desc">We bleven na de Gentse Feesten nog even in Gent hangen bij Barbroos, met London Calling dj's!</p>
                <a href="#" class="event-archive-card__btn">Bekijk de video</a>
              </div>
            </article>

          </div>
        </div>

      </div>

    </div>
  </main>

  <footer class="footer">
  <div class="container footer__inner">

    <!-- Logo + description -->
    <div class="footer__brand">
      <a href="/PROJET-SOCIETE/index.php">
        <img src="/PROJET-SOCIETE/assets/img/logo.png" alt="Dans! Dichter! Dans!" class="footer__logo">
      </a>
      <p class="footer__desc">Un espace où les artistes se rencontrent et où la performance devient mouvement.</p>
    </div>

    <!-- Colonne Media -->
    <nav class="footer__nav" aria-label="Media">
      <h3 class="footer__nav-title">Company</h3>
      <ul>
        <li><a href="/PROJET-SOCIETE/pages/interviews.php">About</a></li>
        <li><a href="/PROJET-SOCIETE/pages/podcast.php">Contact</a></li>

      </ul>
    </nav>

    <!-- Colonne Company -->
    <nav class="footer__nav" aria-label="Company">
      <h3 class="footer__nav-title">Events</h3>
      <ul>
        <li><a href="/PROJET-SOCIETE/pages/about.php">Interviews </a></li>
        <li><a href="/PROJET-SOCIETE/pages/events.php">Podcast</a></li>
        <li><a href="/PROJET-SOCIETE/pages/past-editions.php">Aftermovies</a></li>
        <li><a href="/PROJET-SOCIETE/pages/open-call.php">Teasers</a></li>
      </ul>
    </nav>

    <!-- Newsletter + réseaux sociaux -->
    <div class="footer__newsletter">
      <h3 class="footer__nav-title">Join a Newsletter</h3>
      <label for="newsletter-email">Your Email</label>
      <div class="footer__newsletter-form">
        <input type="email" id="newsletter-email" placeholder="Enter Your Email">
        <button type="button">Subscribe</button>
      </div>
      <div class="footer__social">
        <a href="http://www.instagram.com/dansdichterdans" target="_blank" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
        <a href="https://www.facebook.com/dansdichterdans" target="_blank" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="https://www.youtube.com/channel/UCeXigmFpXBc70l3487iY1jQ" target="_blank" aria-label="Youtube"><i class="fa-brands fa-youtube"></i></a>
      </div>
    </div>

  </div>

  <!-- Barre du bas -->
  <div class="footer__bottom">
    <p>Copyright Team 5</p>
    <div class="footer__bottom-info">
      <span><i class="fa-solid fa-location-dot"></i> Heilig-Hartstraat 16, 9040 Sint-Amandsberg</span>
      <span><i class="fa-solid fa-envelope"></i> info@dansdichterdans.be</span>
      <span><i class="fa-solid fa-phone"></i> +32 488 86 82 11</span>
    </div>
  </div>
</footer>

<script src="/PROJET-SOCIETE/assets/js/main.js"></script>
</body>
</html>
