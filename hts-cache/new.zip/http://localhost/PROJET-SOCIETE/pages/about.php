<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Découvrez qui nous sommes, notre équipe et comment devenir partenaire de Dans! Dichter! Dans!">
<title>À propos — Dans! Dichter! Dans!</title>

<!-- CSS principal  -->
<link rel="stylesheet" href="/PROJET-SOCIETE/assets/css/main.css">

<!-- Icônes FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

  <header class="navbar" id="navbar">
  <div class="navbar__inner">

    <nav class="navbar__left">
      <ul class="navbar__links">
        <li><a href="/PROJET-SOCIETE/pages/about.php" class="navbar__link">About</a></li>
        <li><a href="/PROJET-SOCIETE/pages/events.php" class="navbar__link">Events</a></li>
      </ul>
    </nav>

    <a href="/PROJET-SOCIETE/index.php" class="navbar__logo">
      <img src="/PROJET-SOCIETE/assets/img/logo.png" alt="Dans! Dichter! Dans!">
    </a>

    <nav class="navbar__right">
      <ul class="navbar__links">
        <li><a href="/PROJET-SOCIETE/pages/archives.php" class="navbar__link">Archives</a></li>
        <li><a href="/PROJET-SOCIETE/contact.php" class="navbar__link">Contact</a></li>
      </ul>
    </nav>

    <button class="navbar__burger" id="burger-btn" aria-label="Ouvrir le menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>

  </div>

  <!-- Menu mobile combiné — toutes les pages -->
  <nav class="navbar__mobile-menu" id="mobile-menu" aria-hidden="true">
    <ul>
      <li><a href="/PROJET-SOCIETE/pages/about.php">About</a></li>
      <li><a href="/PROJET-SOCIETE/pages/events.php">Events</a></li>
      <li><a href="/PROJET-SOCIETE/pages/archives.php">Archives</a></li>
      <li><a href="/PROJET-SOCIETE/contact.php">Contact</a></li>
    </ul>
  </nav>

</header>
  <main>

    <!-- ===================================================
         WHO WE ARE
    =================================================== -->
    <section class="apropos-hero">

      <!-- Blobs décoratifs roses — côté gauche -->
      <div class="apropos-blob apropos-blob--l1" aria-hidden="true"></div>
      <div class="apropos-blob apropos-blob--l2" aria-hidden="true"></div>

      <!-- Lettre M décorative — haut gauche -->
      <img class="m-letter m-letter--topleft"
           src="/PROJET-SOCIETE/assets/img/M_letter.png"
           alt="" aria-hidden="true">

      <div class="container">

        <!-- Image large en haut -->
        <div class="apropos-banner-img">
          <img src="/PROJET-SOCIETE/assets/img/about.jpeg"
               alt="Répétition — Dans! Dichter! Dans!">
        </div>

        <!-- Titre -->
        <div class="apropos-hero__title-area">
          <span class="apropos-cursive">About Us</span>
          <h1 class="apropos-hero__title">Who we are ?</h1>
          <p class="apropos-hero__company">Dans! Dichter! Dans!</p>
        </div>

        <!-- Texte en 2 colonnes -->
        <div class="apropos-hero__text-grid">

          <!-- Colonne gauche -->
          <div>
            <p class="apropos-hero__desc">
              Wij zijn een platform en een evenement dat opkomende literaire kunstenaars
              en muzikanten samenbrengt in een veilige ruimte die uitnodigt tot experimenteren.
              Dit resulteert in hoogwaardige optredens voor een breed publiek.
              We streven ernaar de rijkdom en diversiteit van de Vlaamse samenleving te vertegenwoordigen
              en voor iedereen gemakkelijk toegankelijk te zijn.
            </p>
            <p class="apropos-hero__desc">
              We programmeren regelmatig optredens waarin literatuur en muziek worden gecombineerd,
              in de sfeer en energie van een muziekfestival. Voor elke editie gaat
              onze selectie- en programmacommissie op zoek naar nieuw
              literair talent.
            </p>
          </div>

          <!-- Colonne droite -->
          <div class="apropos-hero__right-col">
            <blockquote class="apropos-quote">
              <p>We organiseren regelmatig avonden waarop literatuur en muziek worden gecombineerd, in de sfeer en energie van een muziekfestival. Voor elke editie gaat ons selectie- en programmacomité op zoek naar nieuw literair talent.</p>
              <cite>— Mevrow </cite>
            </blockquote>
          </div>

        </div>
      </div>
    </section>


    <!-- ===================================================
         THE TEAM
    =================================================== -->
    <section class="section section--alt section--team">

      <!-- Lettre M décorative — côté droit, sous les cartes -->
      <img class="m-letter m-letter--right"
           src="/PROJET-SOCIETE/assets/img/M_letter.png"
           alt="" aria-hidden="true">

      <div class="container" style="position: relative;">

        <!-- Blobs décoratifs roses — côté droit -->
        <div class="apropos-blob apropos-blob--r1" aria-hidden="true"></div>
        <div class="apropos-blob apropos-blob--r2" aria-hidden="true"></div>

        <span class="apropos-cursive">the team</span>

        <div class="team__grid">

          <article class="team-card">
            <img class="team-card__photo"
                 src="/PROJET-SOCIETE/assets/img/a1.png"
                 alt="Membre de l'équipe">
            <div class="team-card__body">
              <p class="team-card__name"><span class="team-card__firstname">naam</span> <strong>voornaam</strong></p>
              <p class="team-card__role">BEROEP</p>
            </div>
          </article>

          <article class="team-card">
            <img class="team-card__photo"
                 src="/PROJET-SOCIETE/assets/img/a2.png"
                 alt="Membre de l'équipe">
            <div class="team-card__body">
              <p class="team-card__name"><span class="team-card__firstname">naam</span> <strong>voornaam</strong></p>
              <p class="team-card__role">BEROEP</p>
            </div>
          </article>

          <article class="team-card">
            <img class="team-card__photo"
                 src="/PROJET-SOCIETE/assets/img/a3.png"
                 alt="Membre de l'équipe">
            <div class="team-card__body">
              <p class="team-card__name"><span class="team-card__firstname">naam</span> <strong>voornaam</strong></p>
              <p class="team-card__role">BEROEP</p>
            </div>
          </article>

          <article class="team-card">
            <img class="team-card__photo"
                 src="/PROJET-SOCIETE/assets/img/a4.png"
                 alt="Membre de l'équipe">
            <div class="team-card__body">
              <p class="team-card__name"><span class="team-card__firstname">naam</span> <strong>voornaam</strong></p>
              <p class="team-card__role">BEROEP</p>
            </div>
          </article>

          <article class="team-card">
            <img class="team-card__photo"
                 src="/PROJET-SOCIETE/assets/img/a5.png"
                 alt="Membre de l'équipe">
            <div class="team-card__body">
              <p class="team-card__name"><span class="team-card__firstname">naam</span> <strong>voornaam</strong></p>
              <p class="team-card__role">BEROEP</p>
            </div>
          </article>

          <article class="team-card">
            <img class="team-card__photo"
                 src="/PROJET-SOCIETE/assets/img/a6.png"
                 alt="Membre de l'équipe">
            <div class="team-card__body">
              <p class="team-card__name"><span class="team-card__firstname">naam</span> <strong>voornaam</strong></p>
              <p class="team-card__role">BEROEP</p>
            </div>
          </article>

          <article class="team-card">
            <img class="team-card__photo"
                 src="/PROJET-SOCIETE/assets/img/a7.png"
                 alt="Membre de l'équipe">
            <div class="team-card__body">
              <p class="team-card__name"><span class="team-card__firstname">naam</span> <strong>voornaam</strong></p>
              <p class="team-card__role">BEROEP</p>
            </div>
          </article>

          <article class="team-card">
            <img class="team-card__photo"
                 src="/PROJET-SOCIETE/assets/img/a8.jpeg"
                 alt="Membre de l'équipe">
            <div class="team-card__body">
              <p class="team-card__name"><span class="team-card__firstname">naam</span> <strong>voornaam</strong></p>
              <p class="team-card__role">BEROEP</p>
            </div>
          </article>

          <article class="team-card">
            <img class="team-card__photo"
                 src="/PROJET-SOCIETE/assets/img/a9.jpeg"
                 alt="Membre de l'équipe">
            <div class="team-card__body">
              <p class="team-card__name"><span class="team-card__firstname">naam</span> <strong>voornaam</strong></p>
              <p class="team-card__role">BEROEP</p>
            </div>
          </article>

          <article class="team-card">
            <img class="team-card__photo"
                 src="/PROJET-SOCIETE/assets/img/a10.jpeg"
                 alt="Membre de l'équipe">
            <div class="team-card__body">
              <p class="team-card__name"><span class="team-card__firstname">naam</span> <strong>voornaam</strong></p>
              <p class="team-card__role">BEROEP</p>
            </div>
          </article>

        </div>
      </div>
    </section>


    <!-- ===================================================
         PARTENAIRE ?
    =================================================== -->
    <section class="section">
      <div class="container">

        <span class="apropos-cursive">Partenaire ?</span>

        <div class="partenaire__inner">
          <p class="partenaire__intro">
            Dans! Dichter! Dans! beschikt niet over een eigen zaal, maar kan activiteiten organiseren
            in bestaande locaties of met partners. De inhoud van deze
            activiteiten kan door ons of door de coproducent worden uitgewerkt.
          </p>
          <p class="partenaire__intro">
            Bovendien staan wij als productiehuis ter beschikking van creatieve geesten
            die samen met ons een literaire en muzikale productie willen ontwikkelen.
          </p>

          <h2 class="partenaire__subtitle">Onze verwachtingen:</h2>
          <ul class="partenaire__list">
            <li>Tijdige inzet</li>
            <li>Duidelijke financiële en organisatorische afspraken</li>
            <li>
              Samenwerking voor de organisatie, promotionele communicatie,
              praktische ondersteuning tijdens de activiteit en follow-up na het evenement.
            </li>
            <li>
              Duidelijke en nauwkeurige vermelding van alle partners in de communicatie
              en tijdens de activiteit. Zichtbaarheid in verhouding tot de bijdrage.
            </li>
          </ul>

          <p class="partenaire__contact">
            Neem contact met ons op per post:
            <a href="mailto:info@dansdichterdans.be">info@dansdichterdans.be</a>
          </p>
        </div>

      </div>
    </section>

  </main>

  <footer class="footer">
  <div class="container footer__inner">

    <!-- Logo + description -->
    <div class="footer__brand">
      <a href="/PROJET-SOCIETE/index.php">
        <img src="/PROJET-SOCIETE/assets/img/logo.png" alt="Dans! Dichter! Dans!" class="footer__logo">
      </a>
      <p class="footer__desc">Un espace où les artistes se rencontrent et où la performance devient mouvement.</p>
    </div>

    <!-- Colonne Media -->
    <nav class="footer__nav" aria-label="Media">
      <h3 class="footer__nav-title">Company</h3>
      <ul>
        <li><a href="/PROJET-SOCIETE/pages/interviews.php">About</a></li>
        <li><a href="/PROJET-SOCIETE/pages/podcast.php">Contact</a></li>

      </ul>
    </nav>

    <!-- Colonne Company -->
    <nav class="footer__nav" aria-label="Company">
      <h3 class="footer__nav-title">Events</h3>
      <ul>
        <li><a href="/PROJET-SOCIETE/pages/about.php">Interviews </a></li>
        <li><a href="/PROJET-SOCIETE/pages/events.php">Podcast</a></li>
        <li><a href="/PROJET-SOCIETE/pages/past-editions.php">Aftermovies</a></li>
        <li><a href="/PROJET-SOCIETE/pages/open-call.php">Teasers</a></li>
      </ul>
    </nav>

    <!-- Newsletter + réseaux sociaux -->
    <div class="footer__newsletter">
      <h3 class="footer__nav-title">Join a Newsletter</h3>
      <label for="newsletter-email">Your Email</label>
      <div class="footer__newsletter-form">
        <input type="email" id="newsletter-email" placeholder="Enter Your Email">
        <button type="button">Subscribe</button>
      </div>
      <div class="footer__social">
        <a href="http://www.instagram.com/dansdichterdans" target="_blank" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
        <a href="https://www.facebook.com/dansdichterdans" target="_blank" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="https://www.youtube.com/channel/UCeXigmFpXBc70l3487iY1jQ" target="_blank" aria-label="Youtube"><i class="fa-brands fa-youtube"></i></a>
      </div>
    </div>

  </div>

  <!-- Barre du bas -->
  <div class="footer__bottom">
    <p>Copyright Team 5</p>
    <div class="footer__bottom-info">
      <span><i class="fa-solid fa-location-dot"></i> Heilig-Hartstraat 16, 9040 Sint-Amandsberg</span>
      <span><i class="fa-solid fa-envelope"></i> info@dansdichterdans.be</span>
      <span><i class="fa-solid fa-phone"></i> +32 488 86 82 11</span>
    </div>
  </div>
</footer>

<script src="/PROJET-SOCIETE/assets/js/main.js"></script>
</body>
</html>