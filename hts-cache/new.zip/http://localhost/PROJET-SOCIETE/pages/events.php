<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Ontdek het komende DOGMA Spoken Word Festival op 11-12 juni in Gand. Programma, line-up en media.">
<title>Events — Dans! Dichter! Dans!</title>

<!-- CSS principal  -->
<link rel="stylesheet" href="/PROJET-SOCIETE/assets/css/main.css">

<!-- Icônes FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

  <header class="navbar" id="navbar">
  <div class="navbar__inner">

    <nav class="navbar__left">
      <ul class="navbar__links">
        <li><a href="/PROJET-SOCIETE/pages/about.php" class="navbar__link">About</a></li>
        <li><a href="/PROJET-SOCIETE/pages/events.php" class="navbar__link">Events</a></li>
      </ul>
    </nav>

    <a href="/PROJET-SOCIETE/index.php" class="navbar__logo">
      <img src="/PROJET-SOCIETE/assets/img/logo.png" alt="Dans! Dichter! Dans!">
    </a>

    <nav class="navbar__right">
      <ul class="navbar__links">
        <li><a href="/PROJET-SOCIETE/pages/archives.php" class="navbar__link">Archives</a></li>
        <li><a href="/PROJET-SOCIETE/contact.php" class="navbar__link">Contact</a></li>
      </ul>
    </nav>

    <button class="navbar__burger" id="burger-btn" aria-label="Ouvrir le menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>

  </div>

  <!-- Menu mobile combiné — toutes les pages -->
  <nav class="navbar__mobile-menu" id="mobile-menu" aria-hidden="true">
    <ul>
      <li><a href="/PROJET-SOCIETE/pages/about.php">About</a></li>
      <li><a href="/PROJET-SOCIETE/pages/events.php">Events</a></li>
      <li><a href="/PROJET-SOCIETE/pages/archives.php">Archives</a></li>
      <li><a href="/PROJET-SOCIETE/contact.php">Contact</a></li>
    </ul>
  </nav>

</header>
  <main class="events-page">

    <!-- ===================================================
         HERO — Bannière événement
    =================================================== -->
    <section class="ev-hero">

      <!-- Blobs décoratifs roses (hors overflow du wrapper) -->
      <div class="ev-deco ev-deco--tr" aria-hidden="true"></div>
      <div class="ev-deco ev-deco--mr" aria-hidden="true"></div>

      <div class="ev-hero__wrapper">
        <img src="/PROJET-SOCIETE/assets/img/eventC.png" alt="Event hero" class="ev-hero__bg-img">
        <div class="ev-hero__overlay"></div>
        <div class="ev-hero__content">
          <span class="ev-hero__cursive">Event</span>
          <p class="ev-hero__info">DOGMA spoken Word Festival &nbsp;|&nbsp; 11 - 12 Juin &nbsp;·&nbsp; Gand</p>
          <a href="#event-detail" class="btn btn--hero">Bekijk het komende event</a>
        </div>
        <!-- M1 — à l'intérieur du wrapper, au-dessus de l'image -->
        <img class="ev-m-letter ev-m-letter--top"
             src="/PROJET-SOCIETE/assets/img/M_letter.png"
             alt="" aria-hidden="true">
      </div>
    </section>


    <!-- ===================================================
         TITRE PRINCIPAL
    =================================================== -->
    <section class="ev-title-section" id="event-detail">

      <!-- M2 — niveau titre DOGMA, bord droit -->
      <img class="ev-m-letter ev-m-letter--mid"
           src="/PROJET-SOCIETE/assets/img/M_letter.png"
           alt="" aria-hidden="true">

      <div class="container">
        <h1 class="ev-main-title">DOGMA Spoken Word Festival</h1>
        <p class="ev-main-meta">11 - 12 Juni &nbsp;·&nbsp; Gand</p>
      </div>
    </section>


    <!-- ===================================================
         OVER HET EVENEMENT  +  LINE-UP
    =================================================== -->
    <section class="ev-info-section">

      <!-- M3 — sous le line-up, bord droit, rotation 180° -->
      <img class="ev-m-letter ev-m-letter--bot"
           src="/PROJET-SOCIETE/assets/img/M_letter.png"
           alt="" aria-hidden="true">

      <div class="container ev-info-grid">

        <!-- Colonne gauche : description -->
        <div class="ev-about">
          <h2 class="ev-about__subtitle">Over het evenement</h2>
          <p class="ev-about__text">
            Dans! Dichter! Dans! is een platform waar spoken word centraal staat.
            We ondersteunen opkomende artiesten en geven hen een podium om hun
            verhalen te delen. Door middel van live performances, interviews en
            media bouwen we aan een gemeenschap waar woorden kracht krijgen.
          </p>
          <a href="/PROJET-SOCIETE/pages/about.php" class="btn btn--pink">Meer over ons</a>
        </div>

        <!-- Colonne droite : Line-Up -->
        <div class="ev-lineup">
          <h2 class="ev-lineup__title">Line-Up</h2>
          <div class="ev-lineup__photos">

            <div class="ev-lineup__photo-wrap">
              <img src="/PROJET-SOCIETE/assets/img/e3.png" alt="Artiest 1">
            </div>

            <div class="ev-lineup__photo-wrap">
              <img src="/PROJET-SOCIETE/assets/img/e4.png" alt="Artiest 2">
            </div>

            <div class="ev-lineup__photo-wrap">
              <img src="/PROJET-SOCIETE/assets/img/e5.png" alt="Artiest 3">
            </div>

          </div>
        </div>

      </div>
    </section>


    <!-- ===================================================
         MEDIA
    =================================================== -->
    <section class="ev-media-section">
      <div class="container">

        <span class="ev-media__cursive">Media</span>

        <div class="ev-media__grid">

          <!-- Colonne gauche : 2 vidéos YouTube superposées -->
          <div class="ev-media__videos">

            <div class="ev-media__video-wrap">
              <iframe
                src="https://www.youtube.com/embed/zvKhIGSS0Kw"
                title="Dans! Dichter! Dans! — Aftermovie 1"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen>
              </iframe>
            </div>

            <div class="ev-media__video-wrap">
              <iframe
                src="https://www.youtube.com/embed/zvKhIGSS0Kw"
                title="Dans! Dichter! Dans! — Aftermovie 2"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen>
              </iframe>
            </div>

          </div>

          <!-- Colonne droite : 2 images -->
          <div class="ev-media__images">

            <div class="ev-media__img-wrap">
              <img src="/PROJET-SOCIETE/assets/img/e2.jpeg" alt="Media foto 1">
            </div>

            <div class="ev-media__img-wrap">
              <img src="/PROJET-SOCIETE/assets/img/e1.jpeg" alt="Media foto 2">
            </div>

          </div>

        </div>
      </div>
    </section>

  </main>

  <footer class="footer">
  <div class="container footer__inner">

    <!-- Logo + description -->
    <div class="footer__brand">
      <a href="/PROJET-SOCIETE/index.php">
        <img src="/PROJET-SOCIETE/assets/img/logo.png" alt="Dans! Dichter! Dans!" class="footer__logo">
      </a>
      <p class="footer__desc">Un espace où les artistes se rencontrent et où la performance devient mouvement.</p>
    </div>

    <!-- Colonne Media -->
    <nav class="footer__nav" aria-label="Media">
      <h3 class="footer__nav-title">Company</h3>
      <ul>
        <li><a href="/PROJET-SOCIETE/pages/interviews.php">About</a></li>
        <li><a href="/PROJET-SOCIETE/pages/podcast.php">Contact</a></li>

      </ul>
    </nav>

    <!-- Colonne Company -->
    <nav class="footer__nav" aria-label="Company">
      <h3 class="footer__nav-title">Events</h3>
      <ul>
        <li><a href="/PROJET-SOCIETE/pages/about.php">Interviews </a></li>
        <li><a href="/PROJET-SOCIETE/pages/events.php">Podcast</a></li>
        <li><a href="/PROJET-SOCIETE/pages/past-editions.php">Aftermovies</a></li>
        <li><a href="/PROJET-SOCIETE/pages/open-call.php">Teasers</a></li>
      </ul>
    </nav>

    <!-- Newsletter + réseaux sociaux -->
    <div class="footer__newsletter">
      <h3 class="footer__nav-title">Join a Newsletter</h3>
      <label for="newsletter-email">Your Email</label>
      <div class="footer__newsletter-form">
        <input type="email" id="newsletter-email" placeholder="Enter Your Email">
        <button type="button">Subscribe</button>
      </div>
      <div class="footer__social">
        <a href="http://www.instagram.com/dansdichterdans" target="_blank" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
        <a href="https://www.facebook.com/dansdichterdans" target="_blank" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="https://www.youtube.com/channel/UCeXigmFpXBc70l3487iY1jQ" target="_blank" aria-label="Youtube"><i class="fa-brands fa-youtube"></i></a>
      </div>
    </div>

  </div>

  <!-- Barre du bas -->
  <div class="footer__bottom">
    <p>Copyright Team 5</p>
    <div class="footer__bottom-info">
      <span><i class="fa-solid fa-location-dot"></i> Heilig-Hartstraat 16, 9040 Sint-Amandsberg</span>
      <span><i class="fa-solid fa-envelope"></i> info@dansdichterdans.be</span>
      <span><i class="fa-solid fa-phone"></i> +32 488 86 82 11</span>
    </div>
  </div>
</footer>

<script src="/PROJET-SOCIETE/assets/js/main.js"></script>
</body>
</html>
